<?php include 'include/header.php' ?>

<!-- <style>
  .lazy-image{
    height: 100px;
    width: 100px;
    position: relative;
        background-color: black;
      
    }
    .lazy-image::before{
      content: "";
      height: 100%;
    width: 100%;
    position: absolute;
    left: 200%;
    animation: loading_img_anime 1s infinite;
    background-color: black
    }
    @keyframes loading_img_anime {
        0%{left: -100%;}
        100%{left: 200%;}
    }
</style> -->
<style>
  .client_slider {
    height: 200px;
    width: 100%;
  }
</style>
<div class="container">
  <div class="row my-5 align-items-center">
    <div class="col-lg-6 col-md-12 col-sm-12">
      <div class="">
        <div class="border-left-thick pl-3">
          <p class="h5 mb-3 text-mtem" data-aos="fade-in" data-aos-duration="1000" data-aos-once="true">About us</p>
          <p class="h2" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true">In the Beginning</p>
        </div>
        <div class="pl-3 mt-5">
          <p class="text-dark paragraph" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">In the late
            1990s, the story of <span class="font-weight-bold">Mother
              Transport</span>
            began with a passionate and hardworking individual, Mr. R.
            KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by 2001,
            he
            was handling the supply of bulk materials with just a single lorry. A visionary in the making, he
            expanded
            his
            endeavors, diving into both labor contracting and material supply, laying the foundation for Mother
            Transport.
          </p>
        </div>
      </div>
    </div>
    <div class="col-lg-6 col-md-12 col-sm-12 d-none d-lg-block">
      <div class="d-flex align-items-center justify-content-center">
        <div class="beginning-img" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true">
          <img src="images/homepage/about_img.png" class="object-cover" alt="test-img">
        </div>
      </div>
    </div>
  </div>
</div>



<div class="container my-5">
  <div class="mb-3">
    <p class="h5 mb-3 text-mtem">Expertise</p>
    <p class="h2 font-weight-bold" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Why You Should
    </p>
    <p class="h2 font-weight-bold" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Choose Us</p>
  </div>
  <div>
    <p class="paragraph" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">We offer a diverse range of
      services to cater to your needs, including Foundation Works, Road Work,
      Material
      Supply, and Demolition Work. With our experienced team and top-notch equipment, your projects are in safe
      hands.</p>
    <div class="row mt-3">
      <div class="col-lg-3 col-md-6 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">
        <div class="p-3 bg-light text-center mt-3 hover-box-shadow">
          <p class="h1 text-mtem">33+</p>
          <p>Projects Done</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">
        <div class="p-3 bg-light text-center mt-3 hover-box-shadow">
          <p class="h1 text-mtem">32+</p>
          <p>Happy Customers</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="3000" data-aos-once="true">
        <div class="p-3 bg-light text-center mt-3 hover-box-shadow">
          <p class="h1 text-mtem">56+</p>
          <p>Equipment Fleet</p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="3000" data-aos-once="true">
        <div class="p-3 bg-light text-center mt-3 hover-box-shadow">
          <p class="h1 text-mtem">23</p>
          <p>Years of experience</p>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="my-5 mx-1">
  <div class="my-2 text-center">
    <h2>Our Clients</h2>
  </div>
  <div class="client_slider">
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
    <div class="p-3">
      <img alt="Image" src="images/Baashyaam.jpg" class="object-cover">
    </div>
  </div>
</div>

<?php include 'include/footer.php' ?>

<!-- <script>
  window.addEventListener("load", function() {
  var lazyImages = document.querySelectorAll(".lazy-image");

  var options = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1
  };

  var imageObserver = new IntersectionObserver(function(entries, observer) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var lazyImage = entry.target;
        lazyImage.src = lazyImage.getAttribute("data-src");
        
        lazyImage.addEventListener("load", function() {
          lazyImage.classList.remove("lazy-image");
          imageObserver.unobserve(lazyImage);
        });
      }
    });
  }, options);

  lazyImages.forEach(function(image) {
    imageObserver.observe(image);
  });
});
</script> -->

<script>

  $('.client_slider').slick({
    dots: false,
    arrows: false,
    infinite: true,
    speed: 700,
    autoplay: true,
    autoplaySpeed: 2500,
    slidesToShow: 4,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
        }
      },
      {
        breakpoint: 900,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  });
</script>