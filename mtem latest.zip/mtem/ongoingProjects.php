<?php include 'include/header.php' ?>

<div class="mx-2">

<div class="page_title py-md-3">
    <div class="py-2 py-md-5 mx-lg-5 mx-md-3">
        <h1 class="my-3 font-weight-bold" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">Ongoing Projects</h1>
        <p class="my-3" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">At MTEM, we are constantly at work, bringing visions to life through our ongoing projects. These undertakings reflect our ongoing commitment to excellence and the unwavering dedication to delivering quality services. Here's a glimpse into some of the projects we're currently managing:</p>
    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3">
    <div class="ml-lg-4">
        <h2 class="h4 border-left-thick px-3"><span class="d-block" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Projects in Thiruvallur</span></h2>
    </div>
    <div class="projects_slider" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">

        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>

    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3">
    <div class="ml-lg-4">
        <h2 class="h4 border-left-thick px-3"><span class="d-block" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Projects in Kodambakkam</span></h2>
    </div>
    <div class="projects_slider" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">

        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>

    </div>
</div>

</div>

<?php include 'include/footer.php' ?>