<?php include 'include/header.php' ?>
<div class="mx-2">

<div class="page_title py-md-3">
    <div class="py-2 py-md-5 mx-lg-5 mx-md-3">
        <h1 class="my-3 font-weight-bold">Completed Projects</h1>
        <p class="my-3">At MTEM, our work speaks for itself. We take pride in a rich portfolio of successfully completed projects that showcase our expertise, dedication, and commitment to excellence. Explore some of our most notable achievements below:</p>
    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3">
    <div class="">
        <h2 class="h4 border-left-thick px-3">Projects in Thiruvallur</h2>
    </div>
    <div class="projects_slider">

        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>

    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3">
    <div class="ml-lg-4">
        <h2 class="h4 border-left-thick px-3">Projects in Kodambakkam</h2>
    </div>
    <div class="projects_slider">

        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="project-container">
                <img src="images/projects/project_3.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </div>
        </div>

    </div>
</div>

</div>

<?php include 'include/footer.php' ?>