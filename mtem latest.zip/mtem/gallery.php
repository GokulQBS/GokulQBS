<?php include 'include/header.php' ?>

<div class="my-5">
    <div class="container">
        <div class="col-lg-6">

        </div>
        <div class="col-lg-6">
            <div class="">

            </div>
        </div>
    </div>
</div>

<?php include 'include/footer.php' ?>