<?php include 'include/header.php' ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-6 co9l-md-12 col-sm-12">
        <h1 class="h2 my-4 border-left-thick pl-3">Road Works</h1>
            <h2 class="my-2 h4">More than 20 years of making dreams and new projects come true.</h2>
            <p>At MTEM, we see more than just roads, we see the lifelines of communities and the arteries of progress. Our road works transcend the physical to represent a fusion of art and engineering.</p>
            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the footprint of our craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise of better connectivity, safer journeys, and a brighter future. Join us on this transformative road where innovation, dedication, and quality converge to leave an indelible mark on the world's highways and byways.</p>
        </div>
        <div class="col-lg-6 co9l-md-12 col-sm-12">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
        <div class="col-lg-6 co9l-md-12 col-sm-12">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
        <div class="col-lg-6 co9l-md-12 col-sm-12">
        <h1 class="h2 my-4 border-left-thick pl-3">Excavation Works</h1>
            <h2 class="my-2 h4">More than 20 years of making dreams and new projects come true.</h2>
            <p> Our excavation services are more than just digging; they're about shaping landscapes, preparing foundations, and creating the groundwork for progress. With precision, experience, and a commitment to safety, we transform the earth to meet your unique project needs.</p>
            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the footprint of our craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise of better connectivity, safer journeys, and a brighter future. Join us on this transformative road where innovation, dedication, and quality converge to leave an indelible mark on the world's highways and byways.</p>
        </div>
    </div>


</div>


<?php include 'include/footer.php' ?>