<?php include 'include/header.php' ?>

<!-- <div class="my-lg-5 my-md-2 container">
    <h1 class="h2 mt-4 text-center">Road Works</h1>
    <p>Discover MTEM's road construction and maintenance services, where innovation and dedication intersect to shape the roadways of tomorrow. Our commitment to excellence is evident in every project we undertake, as we endeavor to make travel safer, smoother, and more sustainable..</p>
</div> -->

<div class="container my-5">
    <div class="row">
        <div class="col-lg-6 co9l-md-12 col-sm-12">
        <h1 class="h2 my-4 border-left-thick pl-3">Road Works</h1>
            <h2 class="my-2 h4">More than 20 years of making dreams and new projects come true.</h2>
            <p>At MTEM, we see more than just roads, we see the lifelines of communities and the arteries of progress. Our road works transcend the physical to represent a fusion of art and engineering.</p>
            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the footprint of our craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise of better connectivity, safer journeys, and a brighter future. Join us on this transformative road where innovation, dedication, and quality converge to leave an indelible mark on the world's highways and byways.</p>
        </div>
        <div class="col-lg-6 co9l-md-12 col-sm-12">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
    </div>

    <div class="my-5">
        <h2 class="my-3">Quality Assurance</h2>
        <p>We set our standards sky-high, aiming for roads that outshine the ordinary. Our journey is marked by a commitment to delivering projects that redefine industry standards. With cutting-edge equipment and seasoned expertise, we guarantee that every road we work on reflects our unwavering dedication to quality.</p>
    </div>
</div>

<div class="border-top border-bottom border-verylight">
    <div class="my-5 container">
        <p class="h4">Are you Intersted in This Services ?</p>
        <button class="btn btn-mtem mt-4 ml-3">Quote</button>
    </div>
</div>

<?php include 'include/footer.php' ?>