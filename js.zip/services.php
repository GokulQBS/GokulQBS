<?php include 'include/header.php' ?>
<div class="page_title py-5">
  <div class="py-5 mx-lg-5 mx-md-3">
  <img src="images/sliders/slider-img-4.jpg"  alt="">
    <h1 class=" px-2 heading-content" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Services</h1>
    <p class=" px-2 sub-content text-light" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true"><a href="#">Home</a> / <span>Services</span></p>
  </div>
</div>
<div class="mx-1">

    <div class="mx-lg-5 mx-md-3">
        <style>
            .mtem-btn {
                border: none;
                border-radius: 0;
                padding: 12px;
                margin: 0;
            }

            .mtem-btn:first-child {
                border-bottom-left-radius: 8px;
                border-top-left-radius: 8px;
            }

            .mtem-btn:last-child {
                border-bottom-right-radius: 8px;
                border-top-right-radius: 8px;
            }
        </style>



        <div class="row">
            <div class="col-lg-12 my-3">
                <p class="h5 mb-2 text-mtem">Services</p>
                <div class="d-flex">
                    <button class="mtem-btn btn-primary py-2 services_tabs" data-tab-name="materials_tab">Material
                        Supply</button>
                    <button class="mtem-btn btn-light py-2 services_tabs" data-tab-name="excavation_tab">Excavation
                        Works</button>
                    <button class="mtem-btn btn-light py-2 services_tabs" data-tab-name="road_tab">Road Works</button>
                </div>
            </div>

            <div class="col-lg-12 bg-light">
                <div id="materials_tab" class="services_details px-2">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 order-2 order-md-1" data-aos="fade-right"
                            data-aos-duration="1000" data-aos-once="true">
                            <h1 class="h2 my-4 border-left-thick pl-3">Material Supply</h1>
                            <h2 class="my-2 h4">We offer a wide range of high-quality bulk materials for construction
                                projects, sourced and delivered with precision.</h2>
                            <p>we take pride in offering a comprehensive suite of material supply services that cater to
                                a
                                wide range of construction needs. Our commitment to quality is evident in the materials
                                we
                                provide, which meet and exceed industry standards. From aggregates to sand, gravel, and
                                more, we offer a diverse selection to accommodate various project requirements. Our
                                efficient logistics and reliable sourcing ensure that materials are delivered promptly,
                                minimizing project delays.</p>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 order-1 order-md-2" data-aos="fade-left"
                            data-aos-duration="1000" data-aos-once="true">
                            <div class="services_photos p-2">
                                <img src="images/projects/raw-material.png" alt="" class="object-cover">
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Quality Materials</span>
                                </h3>
                                <p>
                                    We understand that the foundation of any successful construction project lies in the
                                    quality of
                                    materials used. That's why we ensure that all the materials we supply meet and
                                    exceed industry
                                    standards. Our rigorous quality control processes guarantee the reliability and
                                    durability of
                                    the
                                    materials we provide.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 border-left border-right">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Efficient Logistics</span>
                                </h3>
                                <p>
                                    Timely material delivery is critical to project success. With our
                                    efficient logistics
                                    and transportation network, we ensure that materials are delivered promptly to your
                                    project
                                    site,
                                    minimizing delays and helping you stay on schedule.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Client Satisfaction</span>
                                </h3>
                                <p>
                                    Our ultimate goal is to prioritize client satisfaction. We take pride in
                                    contributing to the
                                    success
                                    of your projects by providing top-notch materials and reliable supply services. Your
                                    success is
                                    our
                                    success.
                                </p>
                            </div>
                        </div>
                    </div>




                </div>
                <div id="excavation_tab" class="services_details px-2" style="display:none;">
                    <div class="row">

                        <div class="col-lg-6 col-md-12 col-sm-12 order-2 order-md-1" data-aos="fade-left"
                            data-aos-duration="1000" data-aos-once="true">
                            <h1 class="h2 my-4 border-left-thick pl-3">Excavation Works</h1>
                            <h2 class="my-2 h4">With our state-of-the-art equipment and skilled operators, we handle
                                excavation and earthmoving tasks efficiently and effectively.</h2>
                            <p> Our excavation services are more than just digging; they're about shaping landscapes,
                                preparing
                                foundations, and creating the groundwork for progress. With precision, experience, and a
                                commitment
                                to safety, we transform the earth to meet your unique project needs.</p>
                            <p class="mt-3"> We believe that a road is more than just a thoroughfare, it's a promise of
                                better connectivity, safer journeys, and a brighter future. Join us on this
                                transformative road
                                where innovation, dedication, and quality converge to leave an indelible mark on the
                                world's
                                highways and byways.</p>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 order-1 order-md-2" data-aos="fade-right"
                            data-aos-duration="1000" data-aos-once="true">
                            <div class="services_photos p-2">
                                <img src="images/projects/leveling_work.jpg" alt="" class="object-cover">
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Site Preparation</span></h3>
                                <p>
                                    We understand that the foundation of any successful construction project lies in the
                                    quality of
                                    materials used. That's why we ensure that all the materials we supply meet and
                                    exceed industry
                                    standards. Our rigorous quality control processes guarantee the reliability and
                                    durability of
                                    the
                                    materials we provide.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 border-left border-right">
                            <div class="my-3">
                                <h3 class="h4 "><span class="border-bottom pb-1 border-mtem">Foundation
                                        Excavation</span></h3>
                                <p>
                                    A solid foundation is the heart of every successful structure. Our experts dig with
                                    precision,
                                    ensuring that foundations are structurally sound, setting the stage for safe and
                                    enduring
                                    constructions.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4 "><span class="border-bottom pb-1 border-mtem">Land Clearing</span></h3>
                                <p>
                                    In the natural world's labyrinth, we bring clarity. Our land clearing services
                                    eliminate
                                    obstructions, brush, and debris, revealing open spaces and opportunities for
                                    development while
                                    preserving ecological balance.
                                </p>
                            </div>
                        </div>
                    </div>




                </div>
                <div id="road_tab" class="services_details px-2" style="display:none;">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 order-2 order-md-1" data-aos="fade-right"
                            data-aos-duration="1000" data-aos-once="true">
                            <h1 class="h2 my-4 border-left-thick pl-3">Road Works</h1>
                            <h2 class="my-2 h4">Our team specializes in road construction and maintenance, ensuring safe
                                and
                                efficient transportation networks.</h2>
                            <p>At MTEM, we see more than just roads, we see the lifelines of communities and the
                                arteries of
                                progress.
                                Our road works transcend the physical to represent a fusion of art and engineering.</p>
                            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the
                                footprint of our
                                craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise
                                of
                                better
                                connectivity, safer journeys, and a brighter future. Join us on this transformative road
                                where
                                innovation, dedication, and quality converge to leave an indelible mark on the world's
                                highways and
                                byways.</p>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 order-1 order-md-2" data-aos="fade-left"
                            data-aos-duration="1000" data-aos-once="true">
                            <div class="services_photos p-2">
                                <img src="images/services/road_works.jpg" alt="" class="object-cover">
                            </div>
                        </div>
                    </div>


                    <p>At MTEM, we're dedicated to paving the way for safer, more efficient, and well-connected
                        transportation infrastructure. Our road works services encompass the full spectrum of road
                        construction and maintenance, designed to enhance travel experiences and contribute to the
                        growth
                        and prosperity of communities.</p>

                    <div class="row mt-3">
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Road Construction</span>
                                </h3>
                                <p>
                                    We are masters of the road construction craft, creating roads that stand the test of
                                    time.
                                    Our
                                    comprehensive approach includes meticulous planning, quality materials, and precise
                                    execution to
                                    ensure every road serves its purpose and withstands the elements.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 border-left border-right">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Asphalt Paving</span></h3>
                                <p>
                                    Asphalt is more than just a surface; it's a canvas for smooth and long-lasting
                                    travel. Our
                                    expertise in asphalt paving ensures that road surfaces are not only resilient but
                                    also
                                    contribute to a smoother and more enjoyable journey.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="my-3">
                                <h3 class="h4"><span class="border-bottom pb-1 border-mtem">Quality Assurance</span>
                                </h3>
                                <p>
                                    Our road works services are designed to connect communities, support commerce, and
                                    enhance
                                    daily
                                    life. Whether it's a major highway, a local road, or urban infrastructure, we
                                    believe that
                                    well-constructed and well-maintained roads are the backbone of progress and
                                    connectivity.
                                </p>
                            </div>
                        </div>
                    </div>




                </div>
            </div>
        </div>


        <!-- <div class="mx-lg-5 mb-5">
    <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12 order-2 order-md-1" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
            <h1 class="h2 my-4 border-left-thick pl-3">Road Works</h1>
            <h2 class="my-2 h4">Our team specializes in road construction and maintenance, ensuring safe and efficient transportation networks.</h2>
            <p>At MTEM, we see more than just roads, we see the lifelines of communities and the arteries of progress.
                Our road works transcend the physical to represent a fusion of art and engineering.</p>
            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the footprint of our
                craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise of better
                connectivity, safer journeys, and a brighter future. Join us on this transformative road where
                innovation, dedication, and quality converge to leave an indelible mark on the world's highways and
                byways.</p>
                <a href="servicesDetail.php" class="btn btn-mtem mt-4 ml-3">Read More</a>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 order-1 order-md-2" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
    </div>

    <div class="my-lg-5 my-4 top-bottom-border">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
                <div class="services_photos p-2">
                    <img src="images/services/road_works.jpg" alt="" class="object-cover">
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
                <h1 class="h2 my-4 border-left-thick pl-3">Excavation Works</h1>
                <h2 class="my-2 h4">With our state-of-the-art equipment and skilled operators, we handle excavation and earthmoving tasks efficiently and effectively.</h2>
                <p> Our excavation services are more than just digging; they're about shaping landscapes, preparing
                    foundations, and creating the groundwork for progress. With precision, experience, and a commitment
                    to safety, we transform the earth to meet your unique project needs.</p>
                <p class="mt-3"> We believe that a road is more than just a thoroughfare, it's a promise of better
                    connectivity, safer journeys, and a brighter future. Join us on this transformative road where
                    innovation, dedication, and quality converge to leave an indelible mark on the world's highways and
                    byways.</p>
                    <a href="" class="btn btn-mtem mt-4 ml-3">Read More</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12 order-2 order-md-1" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
            <h1 class="h2 my-4 border-left-thick pl-3">Material Supply</h1>
            <h2 class="my-2 h4">We offer a wide range of high-quality bulk materials for construction projects, sourced and delivered with precision.</h2>
            <p>we take pride in offering a comprehensive suite of material supply services that cater to a wide range of construction needs. Our commitment to quality is evident in the materials we provide, which meet and exceed industry standards. From aggregates to sand, gravel, and more, we offer a diverse selection to accommodate various project requirements. Our efficient logistics and reliable sourcing ensure that materials are delivered promptly, minimizing project delays.</p>
            <a href="" class="btn btn-mtem mt-5 ml-3">Read More</a>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 order-1 order-md-2" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
    </div>
</div> -->

        <div class="my-5 px-2">
            <h2 class="h4">Are you intrested in <span class="d-block d-md-inline"> this service ?</span></h2>
            <a href="contact.php" class="btn btn-dark-blue">Contact Us</a>
        </div>
    </div>
</div>
<?php include 'include/footer.php' ?>

<script>
    $('.services_tabs').on('click', function (event) {
        value = event.target.dataset.tabName;
        console.log(value);
        $('.services_details').hide();
        $('.services_tabs').removeClass('btn-primary');
        $('.services_tabs').addClass('btn-light');
        $(event.target).removeClass('btn-light');
        $(event.target).addClass('btn-primary');
        $('#' + value).show();
    })
</script>