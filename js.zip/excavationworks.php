<?php include 'include/header.php' ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-6 co9l-md-12 col-sm-12">
        <h1 class="h2 my-4 border-left-thick pl-3">Excavation Works</h1>
            <h2 class="my-2 h4">More than 20 years of making dreams and new projects come true.</h2>
            <p> Our excavation services are more than just digging; they're about shaping landscapes, preparing foundations, and creating the groundwork for progress. With precision, experience, and a commitment to safety, we transform the earth to meet your unique project needs.</p>
            <p class="mt-3"> With every project, we sculpt roads that mirror the landscape, bearing the footprint of our craftsmanship. We believe that a road is more than just a thoroughfare, it's a promise of better connectivity, safer journeys, and a brighter future. Join us on this transformative road where innovation, dedication, and quality converge to leave an indelible mark on the world's highways and byways.</p>
        </div>
        <div class="col-lg-6 co9l-md-12 col-sm-12">
            <div class="services_photos p-2">
                <img src="images/services/road_works.jpg" alt="" class="object-cover">
            </div>
        </div>
    </div>

    <div class="my-5">
        <h2 class="my-3">A Commitment to Quality</h2>
        <p>Quality is more than a promise; it's our foundation. With state-of-the-art equipment and a team of experienced operators, we ensure that every excavation task is executed with precision. Rigorous quality control measures and adherence to industry standards underscore our commitment to excellence.</p>
    </div>
</div>

<div class="border-top border-bottom border-verylight">
    <div class="my-5 container">
        <p class="h4">Are you Intersted in This Services ?</p>
        <a href="contact.php" class="btn btn-mtem mt-4 ml-3">Quote</a>
    </div>
</div>

<?php include 'include/footer.php' ?>