<?php include 'include/header.php' ?>
<style>
    .back_line {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        z-index: 99;
        border: 1px solid black;
    }

    .year_start,
    .year_end {
        position: absolute;
        left: -11px;
        z-index: 99;
        color: #434343;
        font-size: 16px;
    }

    .year_start {
        top: -22px;
    }

    .year_end {
        bottom: -22px;
    }

    .year_joining_line {
        display: inline-block;
        height: 20px;
        width: 30px;
        background-color: black;
        clip-path: polygon(0 48%, 100% 48%, 100% 52%, 0 52%);
    }

</style>
<div class="page_title py-5">
  <div class="py-5 mx-lg-5 mx-md-3">
  <img src="images/sliders/slider-img-4.jpg"  alt="">
    <h1 class=" px-2 heading-content" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Completed
            Projects</h1>
    <p class=" px-2 sub-content text-light" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true"><a href="#">Home</a> / <span>Completed
            Projects</span></p>
  </div>
</div>
<div class="mx-3 mt-5 mt-md-2">



    <div class="mx-lg-5 mx-md-3 md-sm-2 my-3 position-relative">
        <i class="back_line"></i>
        <span class="year_start">Start</span>
        <span class="year_end">Ongoing</span>
        <div class="row" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">

            <div class="col-12">
                <p class="h4 text-secondary"><i class="year_joining_line"></i>2021</p>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/gclifespace.jpg" title="GC Lifespace" class="d-block project-container">
                        <img src="images/projects/gclifespace.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">Kovilambakkam</span>
                                GC Lifespace
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/chandrakala.jpg" title="Chandrakala Resort"
                        class="d-block project-container">
                        <img src="images/projects/chandrakala.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">ECR</span>
                                Chandrakala Resort
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/jr_college.jpg" title="JR College Hard Rock Demolishing"
                        class="d-block project-container">
                        <img src="images/projects/jr_college.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">Thindivanam</span>
                                JR College Hard Rock Demolishing
                            </p>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-12">
                <p class="h4 text-secondary"><i class="year_joining_line"></i> 2022</p>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/jr_college_earth_work.jpg" title="JR College Earth Work"
                        class="d-block project-container">
                        <img src="images/projects/jr_college_earth_work.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">Thindivanam</span>
                                JR College Earth Work
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/grand_style_akkarai_site.jpg" title="Grand Style site Road Work"
                        class="d-block project-container">
                        <img src="images/projects/grand_style_akkarai_site.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">Akkarai</span>
                                Grand Style site Road Work
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/power_hydra_nallur.jpg" title="ower DRA" class="d-block project-container">
                        <img src="images/projects/power_hydra_nallur.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">power_hydra_nallur.jpg</span>
                                Power DRA
                            </p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="mx-lg-5 mx-md-3 my-5">
        <p class="h3" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Check our on going projects.
        </p>
        <a href="ongoingProjects.php" class="btn btn-dark-blue" data-aos="fade-left" data-aos-duration="1500"
            data-aos-once="true">ongoing projects</a>
    </div>

</div>

<?php include 'include/footer.php' ?>