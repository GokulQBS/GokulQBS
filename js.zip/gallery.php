<?php include 'include/header.php' ?>
<style>
    .page_title{
        text-align: center;
    }
    .heading-content{
        font-weight: bold;
        color: #0096f7;
    }
</style>

<div class="page_title py-md-3">
    <div class="py-2 py-md-5 mx-lg-5 mx-md-3">
    <img src="images/homepage/section_img.jpg"  alt="">
      
            <h1 class="heading-content" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Our Gallery</h1>
            <p class="sub-content text-light" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true">See Our Gallery: Where Our Work Speaks Louder Than Words</p>
    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">
    <div class="gallery_slider px-lg-3 mx-auto">
        <div class="p-4">
            <a href="images/projects/bashiyam.jpg" title="test" class="d-block project-container">
                <img src="images/projects/bashiyam.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        Bashiyam
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/chandrakala.jpg" title="test" class="d-block project-container">
                <img src="images/projects/chandrakala.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        Chandrakala
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/gclifespace.jpg" title="test" class="d-block project-container">
                <img src="images/projects/gclifespace.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/grand_style_akkarai_site.jpg" title="test" class="d-block project-container">
                <img src="images/projects/grand_style_akkarai_site.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>

    </div>
</div>
<div class="mx-lg-5 mx-md-3 md-sm-2 my-3" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">
    <div class="gallery_slider px-lg-3 mx-auto">
        <div class="p-4">
            <a href="images/projects/jr_college.jpg" title="test" class="d-block project-container">
                <img src="images/projects/jr_college.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/jr_college_earth_work.jpg" title="test" class="d-block project-container">
                <img src="images/projects/jr_college_earth_work.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/power_hydra_nallur.jpg" title="test" class="d-block project-container">
                <img src="images/projects/power_hydra_nallur.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>
        <div class="p-4">
            <a href="images/projects/srm leveling.jpg" title="test" class="d-block project-container">
                <img src="images/projects/srm leveling.jpg" class="object-cover" alt="">
                <div class="project-content">
                    <p class="project-title">
                        <span class="text-primary">Kodambakkam</span>
                        SRM kodambakkam site
                    </p>
                </div>
            </a>
        </div>

    </div>
</div>
<?php include 'include/footer.php' ?>