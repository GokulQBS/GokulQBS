<?php include 'include/header.php'; ?>

<div id="carouselslider" data-side_heading="About" data-side_image="left_nav_img1" class="carousel slide"
    data-ride="carousel" data-interval="3000">

    <ol class="carousel-indicators">
        <li data-target="#carouselslider" data-slide-to="0" class="active"></li>
        <li data-target="#carouselslider" data-slide-to="1"></li>
        <li data-target="#carouselslider" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item position-relative active">
            <img src="images/sliders/slider-img-1.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Excavating Excellence<br>Every Time</p>
                    <p class="carousel-para h6">Your Trusted Partner for Precision Earthworks, Excavation, and
                        Material
                        Supply.
                    </p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative ">
            <img src="images/sliders/slider-img-2.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Shaping Landscapes<br>Building Dreams</p>
                    <p class="carousel-para h6">Bringing Your Projects to Life, Safely and Sustainably. </p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-3.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Quality, Precision,<br>and Commitment</p>
                    <p class="carousel-para h6">We provide Good quality service, at affordable price.</p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-5.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">27 years of <br>Experience</p>
                    <p class="carousel-para h6">we are the The Earthwork Experts you need.</p>
                </div>
            </div>
        </div>

    </div>
</div>

<div class=" mt-5">
    <div class="container">
        <div class="row">
            <div class="order-2 order-md-1 col-lg-6 col-md-12 my-3">
                <h2 class="h3">About Us</h2>
                <p class="my-2">In the late 1990s, the story of Mother Transport began with a passionate and hardworking
                    individual, Mr.
                    R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and
                    by
                    2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the
                    making,
                    he expanded his endeavors, diving into both labor contracting and material supply, laying the
                    foundation
                    for Mother Transport.</p>
                <p class="my-2">
                    After a brief hiatus, Mr. KUPPUSAMY resumed his entrepreneurial journey in 2013 with renewed vigor.
                    This
                    time, he diversified Mother Transport's services by venturing into excavation and earthmoving jobs,
                    utilizing his own fleet of vehicles. This strategic move marked a significant milestone in the
                    company's
                    evolution, showcasing Mr. KUPPUSAMY's adaptability and commitment to meeting the dynamic needs of
                    the
                    industry. Today, Mother Transport stands as a testament to his dedication and foresight in building
                    a
                    versatile and successful business.</p>
                <button class="btn btn-primary mt-3">Read More</button>
            </div>
            <div class="order-1 order-md-2 col-lg-6 col-md-12 p-2 align-center">
                <div class="about-img">
                    <img src="images/homepage/about_img.png" class="object-cover" alt="">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 p-2 align-center">
                <div class="about-img">
                    <img src="images/new_img/mt_images (9).jpg" class="object-cover" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-md-12 my-3">
                <h2 class="h3">Why Us</h2>
                <p class="my-2">In the late 1990s, the story of Mother Transport began with a passionate and hardworking
                    individual, Mr.
                    R. KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and
                    by
                    2001, he was handling the supply of bulk materials with just a single lorry. A visionary in the
                    making,
                    he expanded his endeavors, diving into both labor contracting and material supply, laying the
                    foundation
                    for Mother Transport.</p>
                <p class="">
                    After a brief hiatus, Mr. KUPPUSAMY resumed his entrepreneurial journey in 2013 with renewed vigor.
                    This
                    time, he diversified Mother Transport's services by venturing into excavation and earthmoving jobs,
                    utilizing his own fleet of vehicles. This strategic move marked a significant milestone in the
                    company's
                    evolution, showcasing Mr. KUPPUSAMY's adaptability and commitment to meeting the dynamic needs of
                    the
                    industry. Today, Mother Transport stands as a testament to his dedication and foresight in building
                    a
                    versatile and successful business.</p>
                <button class="btn btn-primary mt-3">Read More</button>
            </div>

        </div>
    </div>

</div>

<div class="d-md-flex justify-content-between align-items-center mt-5">

    <div class="side_content p-2 p-md-5">
        <!-- <h2 class="h3 ">Services</h2> -->
        <h3 class="my-3 border-bottom pb-2">Excavation Works</h3>
        <p>MTEM delivers unparalleled expertise in excavation, offering a comprehensive suite of services to meet
            diverse project needs. From precise site preparation and foundation excavation to specialized rock removal
            and emergency services, we excel in providing efficient, safe, and environmentally responsible solutions.
            Our skilled team, coupled with cutting-edge equipment, ensures that each excavation project is executed with
            precision, contributing to the success and stability of your construction or development endeavors.</p>
            <a href="services.php?focus=excavation" class="btn btn-primary mt-3">Read more</a>
    </div>
    <div class="side_img excavation_services_img">

    </div>
</div>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
    <div class="side_img order-2 order-md-1 material_supply_services_img">

    </div>
    <div class="side_content order-1 order-md-2 p-2 p-md-5">
        <h3 class="my-3 border-bottom pb-2">Materials Supply</h3>
        <p>MTEM is your trusted partner for reliable and efficient materials supply. With a legacy dating back to 1990,
            our commitment to excellence ensures that your project receives high-quality materials, whether it's
            aggregates, sand, or other construction essentials. We take pride in our timely deliveries, transparent
            processes, and a vast network of reliable suppliers, making MTEM the go-to choice for all your construction
            material needs. Choose us for a seamless and dependable materials supply experience that lays the foundation
            for your project's success.</p>
            <a href="services.php?focus=excavation" class="btn btn-primary mt-3">Read more</a>

    </div>

</div>

<div class="d-md-flex justify-content-between align-items-center">
    <div class="side_content p-2 p-md-5">
        <h3 class="my-3 border-bottom pb-2">Road Works</h3>
        <p>At MTEM, we bring a wealth of expertise to road construction and maintenance. Our dedicated team specializes
            in all aspects of road works, from meticulous planning and precise excavation to the application of
            cutting-edge paving technologies. Whether you need new road construction, rehabilitation, or maintenance
            services, MTEM ensures durable, safe, and efficient roadways. With a commitment to quality and adherence to
            industry standards, we take pride in contributing to the development of robust and reliable transportation
            infrastructure. Choose MTEM for road works that stand the test of time.</p>
            <a href="services.php?focus=excavation" class="btn btn-primary mt-3">Read more</a>

    </div>
    <div class="side_img road_services_img">

    </div>
</div>

<div class="mx-2 mx-md-5">
asd
</div>

<?php include 'include/footer.php'; ?>