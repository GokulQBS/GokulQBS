<?php include 'include/header.php' ?>

<div class="py-5 mx-1 position-relative bg-light">
    <i class="contact_bg"></i>
    <div class="text-center my-4">
        <!-- <h1 class="my-3" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true" >Want to <span class="d-block d-md-inline"> Contact Us ?</span></h1> -->
        <h1 class="my-3" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true" >Ready to discuss your material supply and Excavation needs?</h1>
        <p  data-aos="fade-up" data-aos-duration="1500" data-aos-once="true">our team will be happy to assist you in planning and executing your project.</p>
    </div>
    <div class="container mt-5">
        <div class="row align-items-center">
            <div class="col-lg-6"  data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
                <div class="p-4 bg-white shadow-lg rounded-lg">
                    <h2 class="mb-4 mt-2">Contact Us</h2>
                    <input id="form_name" type="text" class="form-control" placeholder="Name">
                    <input id="form_email" type="email" class="form-control my-3" placeholder="Email">
                    <textarea id="form_message" class="form-control" rows="7" placeholder="Subject"></textarea>
                    <button class="btn btn-primary mt-3">Submit</button>
                </div>
            </div>
            <div class="col-lg-6 my-5 my-md-0"  data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
            <div class="text-light ml-3 ml-lg-5">
                <p class="h5 font-weight-bold mb-3">Contact Info:</p>
                <p class="h5 my-2 font-weight-normal">Address:</p>
                <p class="h6 font-weight-normal">
                VELACHERY MAIN ROAD <br>
                PALLIKARANAI CHENNAI.</p>
                <p class="h5 my-2 font-weight-normal">Email:</p>
                <p class="h6 font-weight-normal">motherteam12@gmail.com</p>
            </div>
            </div>
        </div>
    </div>
</div>
<!-- <div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d62218.89813309698!2d80.1287396216797!3d12.928204200000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525da316308de5%3A0xd4404de20ef283bd!2sMOTHER%20TRANSPORT%20%26%20eARTH%20mOVERS!5e0!3m2!1sen!2sin!4v1699264764906!5m2!1sen!2sin" width="100%" height="450px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div> -->

<?php include 'include/footer.php' ?>