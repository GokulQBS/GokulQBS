<?php include 'include/header.php' ?>
<style>
    .back_line {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        z-index: 99;
        border: 1px solid black;
    }

    .year_start,
    .year_end {
        position: absolute;
        left: -11px;
        z-index: 99;
        color: #434343;
        font-size: 16px;
    }

    .year_start {
        top: -22px;
    }

    .year_end {
        bottom: -22px;
    }

    .year_joining_line {
        display: inline-block;
        height: 20px;
        width: 30px;
        background-color: black;
        clip-path: polygon(0 48%, 100% 48%, 100% 52%, 0 52%);
    }


</style>

<div class="page_title py-5">
  <div class="py-5 mx-lg-5 mx-md-3">
  <img src="images/sliders/slider-img-4.jpg"  alt="">
    <h1 class=" px-2 heading-content" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Ongoing Projects</h1>
    <p class=" px-2 sub-content text-light" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true"><a href="#">Home</a> / <span>Ongoing Projects</span></p>
  </div>
</div>
<div class="mx-3">



    <div class="mx-lg-5 mx-md-3 md-sm-2 my-3 position-relative" data-aos="fade-up" data-aos-duration="1000"
        data-aos-once="true">
        <p class="h5 text-mtem">Project Images</p>
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/srm leveling.jpg" title="SRM College trichy"
                        class="d-block project-container">
                        <img src="images/projects/srm leveling.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">Trichy</span>
                                SRM College
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/bashiyam.jpg" title="test" class="d-block project-container">
                        <img src="images/projects/bashiyam.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title text-truncate">
                                <span class="text-primary">Tnagar</span>
                                Baashyam Construction Pvt Ltd
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="p-4">
                    <a href="images/projects/road_works.jpg" title="test" class="d-block project-container">
                        <img src="images/projects/road_works.jpg" class="object-cover" alt="">
                        <div class="project-content-show">
                            <p class="project-title">
                                <span class="text-primary">velachery</span>
                                Hinduja Finance Head Office
                            </p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="mx-lg-5 mx-md-3 my-5">
        <p class="h3" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">Also Check our Completed
            projects. </p>
        <a href="completedProjects.php" class="btn btn-dark-blue" data-aos="fade-left" data-aos-duration="1500"
            data-aos-once="true">Completed projects</a>
    </div>

</div>

<?php include 'include/footer.php' ?>