<?php include 'include/header.php' ?>

<!-- <div class="page_title">
  <div class="my-3 py-3 container">
    <div class="border-left-thick">
      <h1 class="my-3 font-weight-bold pl-3" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">About Us
      </h1>
      <p class="my-3 pl-3" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true">Your Trusted Partner in
        Earthworks, Construction, and Materials Supply.</p>
    </div>
  </div>
</div> -->
<div class="page_title py-5">
  <div class="py-5 mx-lg-5 mx-md-3">
  <img src="images/sliders/slider-img-4.jpg"  alt="">
    <h1 class=" px-2 heading-content" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">About Us</h1>
    <p class=" px-2 sub-content text-light" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true"><a href="#">Home</a> / <span>About us</span></p>
  </div>
</div>

<div class="container">
  <div class="row mb-5 align-items-center">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="my-4">
        <p class="h3 text-mtem">History</p>
        <p class="text-dark paragraph" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">In the late
          1990s, the story of <span class="font-weight-bold">Mother Transport</span>
          began with a passionate and hardworking individual, Mr. R.
          KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by 2001,
          he
          was handling the supply of bulk materials with just a single lorry. A visionary in the making, he
          expanded
          his
          endeavors, diving into both labor contracting and material supply, laying the foundation for Mother
          Transport.
        </p>
        <p class="text-dark paragraph" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
          After a brief hiatus, Mr. KUPPUSAMY resumed his entrepreneurial journey in 2013 with renewed vigor. This time, he diversified Mother Transport's services by venturing into excavation and earthmoving jobs, utilizing his own fleet of vehicles. This strategic move marked a significant milestone in the company's evolution, showcasing Mr. KUPPUSAMY's adaptability and commitment to meeting the dynamic needs of the industry. Today, Mother Transport stands as a testament to his dedication and foresight in building a versatile and successful business.
        </p>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <div class="my-3" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
            <h2 class="h4 my-4 border-left-thick pl-3 text-mtem">Our Values</h2>
            <h3 class="h5 mt-2">Quality</h3>
            <p>Our commitment to quality is non-negotiable. We invest in advanced technology, training, and a rigorous
              quality
              assurance process to ensure our work is second to none.</p>
            <h3 class="h5 mt-2">Safety</h3>
            <p>The well-being of our team members, clients, and the environment is paramount. Safety is ingrained in
              our
              culture, and we continuously improve our practices to minimize risks.</p>
            <h3 class="h5 mt-2">Sustainability</h3>
            <p>We recognize our responsibility to protect the environment and support sustainable practices in our
              work.
              Our
              aim is to balance progress with preservation.</p>
          </div>
        </div>
        <div class="col-lg-6">

          <div class="d-flex align-items-center justify-content-center">
            <div class="about-img my-3" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true">
              <img src="images/sliders/slider-img-55.png" class="object-cover" alt="test-img">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container my-5">
  <div class="row">
    <div class="col-lg-6 col-md-6" data-aos="fade-right" data-aos-duration="1000" data-aos-once="true">
      <div class="p-1">
        <div class="border p-3">
          <p class="h2 font-weight-bold text-mtem" data-aos="fade-right" data-aos-duration="1500" data-aos-once="true">
            Our Vision </p>
          <p class="mt-3">Our mission is to be a trusted leader in the transport and earth movers industry,
            continuously
            delivering reliability and efficiency. We achieve this through a steadfast commitment to quality,
            unwavering
            honesty, and a tireless work ethic.</p>
        </div>
      </div>
    </div>
    <div class="col-lg-6 col-md-6" data-aos="fade-left" data-aos-duration="1000" data-aos-once="true">
      <div class="p-1">
        <div class="border p-3">
          <p class="h2 font-weight-bold text-mtem" data-aos="fade-left" data-aos-duration="1500" data-aos-once="true">
            Our Mission </p>
          <p class="mt-3">Our vision is to lead the way in the transport and earth movers industry, setting new
            standards through innovation and sustainability. We aspire to be the catalyst for positive change and a
            trusted partner in shaping the future of construction and transportation..</p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<div class="my-5 mx-1">
  <div class="my-2 text-center text-mtem" data-aos="fade-up" data-aos-duration="1000" data-aos-once="true">
    <h2>Our Clients</h2>
  </div>
  <div class="client_slider">
    <div class="p-4">
      <img alt="Image" src="images/clients/adroit.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/akshiya.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/Appaswamy.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/casagrand.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/dec_infra.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/greenLeaves.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/hirini.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/mmaFoundation.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/ramboo_builders.png" class="object-contain">
    </div>
    <div class="p-4">
      <img alt="Image" src="images/clients/srm.png" class="object-contain">
    </div>
  </div>
</div>

<?php include 'include/footer.php' ?>

<script>

  $('.client_slider').slick({
    dots: false,
    arrows: false,
    infinite: true,
    speed: 700,
    autoplay: true,
    autoplaySpeed: 2500,
    slidesToShow: 4,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
        }
      },
      {
        breakpoint: 900,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  });
</script>