<?php include 'include/header.php' ?>

<div id="home_carousel" class="carousel slide" data-ride="carousel">

    <ol class="carousel-indicators">
        <li data-target="#home_carousel" data-slide-to="0" class="active"></li>
        <li data-target="#home_carousel" data-slide-to="1"></li>
        <li data-target="#home_carousel" data-slide-to="2"></li>
    </ol>
    
    <div class="carousel-inner">
        <img src="images/slider/slider_bg2.png" alt="" class="sliders_bg">
        <div class="carousel-item active">

            <div class="carousel_img">
                <img src="images/slider/slide (1).jpg" class="d-block w-100 object-cover" alt="...">
            </div>
            <div class="carousel-caption">
            <div>
                    <h5 class="h1">Precision in Every Beam, Strength in Every Structure.</h5>
                    <p>Strength Redefined, Structures Refined..</p>
                </div>
            </div>
        </div>
        <div class="carousel-item">

        <div class="carousel_img">
            <img src="images/slider/slide (6).jpg" class="d-block w-100 object-cover" alt="...">
            </div>
            <div class="carousel-caption">
                <div>
                    <h5 class="h1">Strength in Precision, Innovation in Construction.</h5>
                    <p>Your Vision, Our Steel. Building Tomorrow, Today.</p>
                </div>
            </div>
        </div>
        <div class="carousel-item">

        <div class="carousel_img">
            <img src="images/slider/slide (3).jpg" class="d-block w-100 object-cover" alt="...">
            </div>
            <div class="carousel-caption">
            <div>
                    <h5 class="h1">Beyond Boundaries, Building Excellence.</h5>
                    <p>Innovative PEB Solutions for a Limitless Future.</p>
                </div>
            </div>
        </div>
    </div>

    <button class="carousel-control-prev" type="button" data-target="#home_carousel" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-target="#home_carousel" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </button>
</div>

<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="p-2">
                    <h2 class="my-3 title-border-bottom">About Us</h2>
                    <p>We being the expert in Pre-Engineering structures with 30 years of experience, started our
                        journey in 1989 in the name ‘Hi-Tech Structurals Private Limited’ and continued providing
                        esteemed services in the field till 2010
                    </p>
                    <p class="mt-3">We are driving Manufacturer of an ideal quality scope of PEB structure, Industrial
                        Shed, production line shed, Prefabricated Structure, Prefabricated Industrial Shed,
                        Prefabricated Factory Shed. Our offered range is broadly acclaimed for their ideal quality,
                        consumption opposition, and toughness.
                    </p>
                    <a href="#" class="btn btn-massinfra mt-4">Learn More</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-img">
                    <img src="images/slider/slide (3).jpg" class="object-cover" alt="">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-5 pb-5 pt-3">
    <div class="container">
        <div class="my-3 text-center">
        <p class="h6">WHAT WE PROVIDE</p>
            <h2 class="my-3"><span class="title-border-bottom px-4">EXCLUSIVE SERVICES</span></h2>
        </div>
        <div class="mx-0 mx-md-5">
        <div class="row">

            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/peb contractors.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB CONTRACTORS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We supply prefabricated buildings as a complete item alongside steel structures, building adornments and rooftop cladding.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/ped_structure.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB STRUCTURE</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>PEB structures can be extended effectively and are intended to withstand all climatic condition without support.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/steal_building.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB STEEL BUILDINGS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We supply a wide scope of Pre Engineered Building which is made of premium quality material which is sturdy and successful in application in development businesses.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/warehouse.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB INDUSTRIAL SHEDS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We have ability in designing, manufacturing Sheds to our esteemed customers. We create these sheds utilizing advance innovation guaranteeing subjective item at client's end. </p>
                     </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </div>
</div>

<!-- <div class="mt-5 pb-5 pt-3">
    <div class="container">
        <div class="my-3 text-center">
        <p class="h6">WHAT WE PROVIDE</p>
            <h2 class="my-3"><span class="title-border-bottom px-4">EXCLUSIVE SERVICES</span></h2>
        </div>
        <div class="mx-0 mx-md-5">
        <div class="row">

            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/peb contractors.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB CONTRACTORS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We supply prefabricated buildings as a complete item alongside steel structures, building adornments and rooftop cladding.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/ped_structure.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB STRUCTURE</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>PEB structures can be extended effectively and are intended to withstand all climatic condition without support.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/steal_building.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB STEEL BUILDINGS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We supply a wide scope of Pre Engineered Building which is made of premium quality material which is sturdy and successful in application in development businesses.</p>
                     </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="p-4">
                    <div class="services_img shadow-md">
                     <img  src="images/services/warehouse.jpg" class="object-cover" alt="">
                     <div class="border_name">
                        <div class="d-flex justify-contents-left align-items-center">
                            <div class="border_img">
                                <img src="images/icons/structure.png" alt="" class="object-contain">
                            </div>
                            <p class="h5 text-dark">PEB INDUSTRIAL SHEDS</p>
                        </div>
                     </div>
                     <div class="border_content">
                        <p>We have ability in designing, manufacturing Sheds to our esteemed customers. We create these sheds utilizing advance innovation guaranteeing subjective item at client's end. </p>
                     </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </div>
</div> -->

<div class="mb-5 py-5 experience_parallex">
    <div class="container py-5">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2 class="text-light">Our reputation is strong as concret, give us a try</h2>
                <p class="mt-3 text-light">We help your dreams come to reality</p>
                <button class="btn btn-massinfra mt-3">Contact Now</button>
            </div>
            <div class="col-lg-6 mt-4 mt-md-0">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <div class="p-2 experience_animation">
                            <div class="experience_container">
                                <h2>100+</h2>
                                <p>Completed Projects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="p-2 experience_animation">
                            <div class="experience_container">
                                <h2>70+</h2>
                                <p>Happy Customers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="p-2 experience_animation">
                            <div class="experience_container">
                                <h2>12+</h2>
                                <p>Year Exprience</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="p-2 experience_animation">
                            <div class="experience_container">
                                <h2>60+</h2>
                                <p>Current staff</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="my-5">
    <div class="container">
        <div class="my-3 text-center">
            <p class="my-5 h3"><span class="title-border-bottom pr-4">Contact us </span></p>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <div class="p-2 px-lg-5">
                    <h2 class="my-4">Have an upcoming project ?</h2>
                    <input type="text" class="form-control" placeholder="Name">
                    <input type="Email" class="form-control my-3" placeholder="Email">
                    <textarea name="" class="form-control" placeholder="Message"></textarea>
                    <button class="btn btn-massinfra mt-3">Submit</button>
                </div>
            </div>
            <div class="col-lg-5 d-none d-md-block">
                <div class="contact-img">
                    <img src="images/contact_img.jpg" class="object-cover" alt="">
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'include/footer.php' ?>
