Inspiration:

http://preview.themeforest.net/item/liarch-architecture-interior-html-template/full_screen_preview/30325598?_ga=2.28996991.271705022.1699683719-1710166018.1689831168

http://paul-themes.com/html/liarch/home-parallax-dark.html

http://paul-themes.com/html/liarch/home-modern-dark.html

http://paul-themes.com/html/liarch/home-default-dark.html

https://builty.bslthemes.com/

https://builty.bslthemes.com/home-3/

https://builty.bslthemes.com/