<footer>
  <div class="py-4 footer-top">
    <div class="curve"></div>
    <div class="container">

      <div class="row">
        <div class="col-lg-3">
        <div class="logo_container d-flex justify-contents-center align-items-center">
     <a class="logo" href="#">
       <img src="massinfra_logo.png" alt="" class="object-contain">
     </a>
     <div>
       <p class="h5 mb-0">Mass Infra</p>
       <p class="h6">Projects and Services</p>
     </div>
      </div>
          <p class="">We Undertaken many structural, interior works and telecommunication  projects including HDD works in Muscat
            and UAE from 2011 to 2017</p>
        </div>
        <div class="col-lg-3 pl-3">
          <p class="h4">What we do</p>
          <ul class="footer_points footer_points_bullet">
            <li>PEB Structures</li>
            <li>PEB Steel Building</li>
            <li>PEB Steel Building</li>
            <li>PEB Industrial Sheds</li>
            <li>PEB Contractors</li>
          </ul>
        </div>
        <div class="col-lg-3">
          <p class="h4">Contact Us</p>
          <ul >
            <li class="py-1"><i class="fa-solid fa-house pr-3"></i>255, First floor, Poonamallee High Road, Aminjikarai, Chennai - 600 029.</li>
            <li><i class="fa-solid fa-phone pr-3"></i>+ 91 9841098925</li>
            <li class="py-1"><i class="fa-solid fa-phone pr-3"></i>+ 91 44 48554122</li>
          </ul>
        </div>
        <div class="col-lg-3">
          <p class="h4">About Mass Infra</p>
          <ul class="footer_points footer_points_bullet">
            <li>About Us</li>
            <li>Services</li>
            <li>Our Projects</li>
            <li>Contact Us</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
  <div class="py-3 footer-bottom bg-light">
    <div class="text-center w-lg-50">All rights reserved by qbrainstorm.com</div>
  </div>
</footer>

</main>
<script src="js/script.js"></script>
<script src="js/parallax.min.js"></script>
<script>
  $('.experience_parallex').parallax({ imageSrc: 'images/experience_bg1.jpg' });
  $('#home_carousel').on('slide.bs.carousel', function (event) {
console.log(event.to);
console.log('triggered');

});
</script>
</body>

</html>