<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="massinfra_logo.png" sizes="32x32" />
  <link rel="icon" href="massinfra_logo.png" sizes="192x192" />
  <meta name="description" content="">
  <meta name="keywords" content="">
  <title>Mass Infra</title>
</head>

<body>
  <main class="">
    <nav class="navbar navbar-expand-lg navbar-dark  px-3 pr-5">

      <div class="logo_container d-flex justify-contents-center align-items-center">
        <a class="logo" href="#">
          <img src="massinfra_logo.png" alt="" class="object-contain">
        </a>
        <div>
          <p class="h5 mb-0 text-light">Mass Infra</p>
          <p class="h6 text-light">Projects and Services</p>
        </div>
      </div>


      <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
        aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavId">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Service</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Projects</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </nav>